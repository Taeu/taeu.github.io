---
layout: tag-blog
title: Startup
slug: startup
category: essay
menu: false
order: 1
header-img: "/img/startup-logo.jpg"
---
