---
layout: list
title: Review
slug: review
menu: true
submenu: true
order: 6
description: >
  보고 사용한것들을 리뷰합니다. 라이트한 축에 속하는 하드웨어덕이며, 술, 맛집 등을 좋아합니다.
---
