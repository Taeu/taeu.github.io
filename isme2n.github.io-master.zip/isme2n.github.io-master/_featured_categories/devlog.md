---
layout: list
title: Devlog
slug: devlog
menu: true
submenu: true
order: 8
description: >
  개발과 관련된 글을 적습니다. Node.js Meteor React 외에도 개념, 디자인패턴 소프트웨어 공학적인 부분들을 다룹니다.

---
